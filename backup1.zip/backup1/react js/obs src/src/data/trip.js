const trip = {
  status: true,
  data: {
    id: 1,
    from_city: "mogadishu",
    to_city: "garowe",
    bus_id: 1,
    trip_date: "2022-03-08",
    depature: "8:00",
    arrival: "12:00",
    price: 25.0,
    bus_name: "bus-001",
    front_seats: 2,
    body_seats: 20,
  },
  booked: ["S-3", "S-5"],
};

export function getTrip() {
  return trip;
}
