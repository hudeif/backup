import React, { Component } from "react";
import Seats from "./seats";
import { getTrip } from "../data/trip";

class SeatsView extends Component {
  state = {};

  layout = { bodySeats: 0, col: 4, booked: [] };

  async componentDidMount() {
    const tripResponse = await getTrip();
    this.layout.bodySeats = tripResponse.data.body_seats;
    this.layout.booked = tripResponse.booked;
    this.setState({ tripResponse });
  }

  render() {
    // const layout = {
    //   bodySeats: 12,
    //   col: 4,
    // };
    // console.log(layout);
    return (
      <div>
        <Seats layout={this.layout} data={this.state.tripResponse} />
      </div>
    );
  }
}

export default SeatsView;
