import React, { Component } from "react";

class Seat extends Component {
  state = {
    seat: {
      isClicked: false,
      isBooked: this.props.isBooked,
    },
  };

  handleClick = (e) => {
    const isClicked = this.state.seat.isClicked;
    if (!this.state.seat.isBooked) {
      this.setState({ seat: { isClicked: !isClicked } });
      this.props.pushSeat(e.target.getAttribute("label"));
    }
  };

  renderClasses = () => {
    let classes = "seat ";
    const { isClicked, isBooked } = this.state.seat;

    isClicked ? (classes += "active-seat") : (classes += "");

    isBooked ? (classes += "booked") : (classes += "");

    return classes;
  };

  render() {
    const { label } = this.props;
    return (
      <div
        onClick={this.handleClick}
        key={label}
        className={this.renderClasses()}
        label={"S-" + label}
      >
        {label}
      </div>
    );
  }
}

export default Seat;
