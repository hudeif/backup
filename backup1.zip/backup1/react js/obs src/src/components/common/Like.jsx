import React from "react";

const Like = ({ liked, onClick }) => {
  return (
    <i
      onClick={onClick}
      className={
        liked ? "fas fa-heart fa-lg text-danger" : "far fa-lg fa-heart"
      }
      aria-hidden="true"
    ></i>
  );
};

export default Like;
