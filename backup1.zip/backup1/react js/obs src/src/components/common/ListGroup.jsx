import React from "react";

const ListGroup = ({
  items,
  valueProperty,
  textProperty,
  selectedGenre,
  onItemSelect,
}) => {
  return (
    <ul className="list-group">
      {items.map((item) => {
        return (
          <li
            onClick={() => onItemSelect(item)}
            key={item[valueProperty]}
            className={
              item === selectedGenre
                ? "list-group-item active"
                : "list-group-item"
            }
          >
            {item[textProperty]}
          </li>
        );
      })}
    </ul>
  );
};

ListGroup.defaultProps = {
  valueProperty: "_id",
  textProperty: "name",
};
export default ListGroup;
