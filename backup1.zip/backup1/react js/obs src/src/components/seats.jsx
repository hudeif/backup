import React, { Component } from "react";
import { renderSeats } from "../utils/renderRow";
import Seat from "./seat";

class Seats extends Component {
  state = {
    layout: this.props.layout,
  };

  seatsarr = [];
  selected = [];

  pushSelected = (seat) => {
    this.selected.push(seat);
    console.log(this.selected);
  };

  showSeats = () => {
    const { layout } = this.state;

    this.seatsarr.length = 0; // had problem when rerender is happen and this is solution
    for (let i = 1; i <= layout.bodySeats; i++) {
      this.seatsarr.push(i);
    }

    let rows = Math.ceil(layout.bodySeats / layout.col);
    let output = [];

    const booked = layout.booked;

    for (let i = 1; i <= rows; i++) {
      let res = renderSeats(this.seatsarr, i, layout.col);

      let result = res.map((s) => {
        return (
          //   <div key={s} className="seat" label="">
          //     {s}
          //   </div>
          <Seat
            key={s}
            label={s}
            pushSeat={this.pushSelected}
            isBooked={booked.includes("S-" + s)}
          />
        );
      });

      output.push(
        <div key={Math.random()} className="row">
          {result}
        </div>
      );
    }

    return output;
  };

  render() {
    return (
      <div>
        <div className="status">
          <div>
            <span className="status-sign selected"></span>
            <span>selected</span>
          </div>
          <div>
            <span className="status-sign available"></span>
            <span>available</span>
          </div>
          <div>
            <span className="status-sign booked-status"></span>
            <span>booked</span>
          </div>
        </div>
        <div className="seat-wrapper">
          <div className="front-seats">
            <div className="row"></div>
          </div>
          <div className="body-seats">{this.showSeats()}</div>
        </div>
      </div>
    );
  }
}

export default Seats;
