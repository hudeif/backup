import _ from "lodash";

export function renderSeats(seats, rowNumber, rowSize) {
  const startIndex = (rowNumber - 1) * rowSize;
  return _(seats).slice(startIndex).take(rowSize).value();
}
