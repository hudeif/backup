import logo from "./logo.svg";
import "./App.css";
import SeatsView from "./components/seatsView";

function App() {
  return <SeatsView />;
}

export default App;
