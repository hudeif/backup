import Movies from "./components/Movies";
import NavBar from "./components/NavBar";
import { Routes, Route, Link } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <NavBar />
      <nav className="navbar navbar-expand">
        <ul className="navbar-nav">
          <li className="nav-item">
            <Link to="/expenses" className="nav-link">
              expenses
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/invoices" className="nav-link">
              invoices
            </Link>
          </li>
        </ul>
      </nav>
      <main className="container mt-5">
        <Routes>
          <Route path="/" element={<Movies />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
