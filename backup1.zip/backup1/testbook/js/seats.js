let params = new URL(document.location).searchParams;
let tripId = params.get("tripid");

getTripInfo(tripId);

let layout = {};
let seatsArr = [];
$(".calculations").hide();
function getTripInfo(tripId) {
  let sendingData = { tripId, action: "getTripInfo" };
  $.ajax({
    method: "POST",
    url: "./api/Trips.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let response = data.data;
      let bookedSeats = data.booked;

      layout = {
        frontSeats: response.front_seats,
        bodySeats: response.body_seats,
        col: 4,
        booked: bookedSeats,
      };

      $("#from").val(response.from_city);
      $("#to").val(response.to_city);

      for (let i = 1; i <= layout.bodySeats; i++) {
        seatsArr.push(i);
      }

      let frontRows = Math.ceil(layout.frontSeats / layout.col);

      let frontHtml = "";

      for (let i = 1; i <= frontRows; i++) {
        frontHtml += `
       ${showFrontSeats(layout.frontSeats)}
      `;
      }

      $(".seat-wrapper .front-seats .row").append(frontHtml);

      let rows = Math.ceil(layout.bodySeats / layout.col);
      //   console.log(rows);
      let html = "";

      for (let i = 1; i <= rows; i++) {
        // html += `<div class="row">
        //       <div class="seat"></div>
        //       <div class="seat"></div>
        //       <div class="seat"></div>
        //       <div class="seat"></div>
        //     </div>`;
        html += `<div class="row">`;

        let res = renderSeats(seatsArr, i, layout.col);
        res.forEach((s) => {
          html += `<div class="seat" label="${"S-" + s}">${s}</div>`;
        });

        html += `</div>`;
        // console.log(res);
      }
      $(".seat-wrapper .body-seats").append(html);

      let seats = document.querySelectorAll(".seat");
      let selectedSeats = [];
      seats.forEach((seat) => {
        let label = seat.getAttribute("label");
        if (layout.booked.includes(label)) {
          seat.classList.add("booked");
          seat.disabled = true;
        } else {
          seat.addEventListener("click", () => {
            seat.classList.toggle("active-seat");

            if (seat.classList.contains("active-seat")) {
              let seatNo = seat.getAttribute("label");
              selectedSeats.push(seatNo);
            } else {
              let seatNo = seat.getAttribute("label");
              let index = selectedSeats.indexOf(seatNo);
              selectedSeats.splice(index, 1);
            }

            $(".calculations .seats_calc").html("");
            $(".calculations .total_calc").html("");
            $(".calculations .head").html("");

            selectedSeats.forEach((s) => {
              $(".calculations .seats_calc")
                .append(`<div class="seat-container">
              <p class="seat_name">${s}</p>
              <p class="seat_">$ ${Math.round(response.price * 100) / 100}</p>
            </div>`);
            });

            if (selectedSeats.length > 0) {
              $(".calculations").show();

              $(".calculations .head").append(`<div class="head-container">
              <p>Selected seat</p>
              <p>price</p>
            </div>`);

              $(".calculations .seats_calc")
                .append(`<div class="total-container">
              <p>Subtotal</p>
              <p>$ ${selectedSeats.length * response.price}</p>
            </div>`);
            } else {
              $(".calculations").hide();
            }

            localStorage.setItem(
              "selectedSeats",
              JSON.stringify(selectedSeats)
            );
          });
        }
      });

      console.log();

      tippy(".seat", {
        content: "available.",
      });

      tippy(".booked", {
        content: "booked.",
      });
    },
  });
}

function showFrontSeats(seats) {
  let content = "";
  for (let x = 1; x <= seats; x++) {
    content += ` <div class="seat" label="${"F-" + x}">${"F-" + x}</div>`;
  }

  return content;
}

// currentRow = 1,rowSize = 4 ,totalSeats = 12,
// const rowCount = Math.ceil(totalSeats / rowSize);

function renderSeats(seats, rowNumber, rowSize) {
  const startIndex = (rowNumber - 1) * rowSize;
  return _(seats).slice(startIndex).take(rowSize).value();
}

// seats.forEach((seat) => {
//   let label = seat.getAttribute("label");

//   if (layout.booked.includes(label)) {
//     seat.classList.add("booked");
//     seat.disabled = true;
//   }
// });

let bookBtn = document.querySelector(".btn-book");

$("#journey-form").on("submit", (e) => {
  e.preventDefault();
  let items = JSON.parse(localStorage.getItem("selectedSeats")) || [];

  if (items.length === 0) return alert("please select a seat");
  let info = {
    name: "a",
    from: "b",
    to: "c",
    booked: items,
  };
  return console.log(info);
});

window.addEventListener("load", () => {
  localStorage.setItem("selectedSeats", JSON.stringify([]));
});
