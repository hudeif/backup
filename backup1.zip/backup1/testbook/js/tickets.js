$("#ticketFilterForm").on("submit", (e) => {
  e.preventDefault();

  let from = $("#from").val();
  let to = $("#to").val();

  let sendingData = { from, to, action: "searchTrips" };

  $.ajax({
    method: "POST",
    url: "./api/Trips.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      console.log(response);
      let html = "";
      if (status) {
        response.forEach((trip) => {
          html += `
        <div class="ticket">
            <div>
            <h3>${trip.from_city + " - " + trip.to_city}</h3>
            <p>seat layout 1L</p>
            <p>AC</p>
            </div>
            <div>${trip.depature + " - " + trip.arrival}</div>
            <div>
            <p>$${trip.price}</p>
            <a href='seats.html?tripid=${
              trip.id
            }' class="btn btn-success">Book now</a>
            </div>
        </div>
        `;
        });

        $("#tickets-container").append(html);
      } else {
      }
    },
    error: function (data) {},
  });
});
