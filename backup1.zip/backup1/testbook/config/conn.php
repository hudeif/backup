<?php

$conn = mysqli_connect('localhost','root','','testbus');
if($conn->connect_error){
    echo $conn->error;
}