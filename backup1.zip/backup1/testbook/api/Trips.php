<?php
header("Content-type:application/json");
include '../config/conn.php';

function searchTrips($conn){
    extract($_POST);
    $data = array();
    $data_array = array();

    $query = "SELECT * FROM `trip` WHERE from_city='$from' and to_city='$to'";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $data_array [] = $row;
        }

        $data = array("status" => true, "data" => $data_array);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function getTripInfo($conn){
    extract($_POST);
    $data = array();
    $data_array = array();

    $query = "SELECT * FROM `trip`
    LEFT JOIN bus on trip.bus_id = bus.id
    WHERE trip.id ='$tripId'";
    $result = $conn->query($query);

    $bookedQuery = "SELECT seat_no FROM `booked_seats` WHERE trip_id='$tripId'";
    $bookedResult = $conn->query($bookedQuery);

    if($result){
        $row = $result->fetch_assoc();

        while($bookedRow = $bookedResult->fetch_assoc()){
            $data_array [] = $bookedRow['seat_no'];
        }

        $data = array("status" => true, "data" => $row,"booked"=>$data_array);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status" => false, "data" => "action is required."));
}

?>