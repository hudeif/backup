class Paddle {
  constructor(paddleElem) {
    this.paddleElem = paddleElem;
  }
}
