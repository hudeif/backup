package com.example.RelationshipsTest.Models;

import javax.persistence.*;

@Entity
public class Office {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    private String location;

    @OneToOne
    @JoinColumn(name="manager_id",referencedColumnName = "Id")
    Manager manager;

    public Office(Integer id, String location, Manager manager) {
        Id = id;
        this.location = location;
        this.manager = manager;
    }

    public Office() {
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
}
