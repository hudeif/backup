package com.example.RelationshipsTest.Models;

import javax.persistence.*;
import java.util.List;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    private String studentName;

    @ManyToMany(mappedBy = "studentList")
    private List<Course> course;

    public Student(Integer id, String studentName, List<Course> course) {
        Id = id;
        this.studentName = studentName;
        this.course = course;
    }

    public Student() {
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public List<Course> getCourse() {
        return course;
    }

    public void setCourse(List<Course> course) {
        this.course = course;
    }
}
