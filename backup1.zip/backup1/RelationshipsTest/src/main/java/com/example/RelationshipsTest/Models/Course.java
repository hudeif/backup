package com.example.RelationshipsTest.Models;

import javax.persistence.*;
import java.util.List;

@Entity
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    private String courseTitle;

    @ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinTable(name="enrollment",
    joinColumns = @JoinColumn(name = "student_id",referencedColumnName = "Id"),
    inverseJoinColumns = @JoinColumn(name = "course_id",referencedColumnName = "Id"))
    private List<Student> studentList;
}
