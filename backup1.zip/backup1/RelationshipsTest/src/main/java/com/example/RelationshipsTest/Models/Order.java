package com.example.RelationshipsTest.Models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer orderId;

    private String productName;
    private String price;

    @ManyToOne(optional = false)
    @JsonIgnoreProperties(value = {"orderList", "handler","hibernateLazyInitializer"}, allowSetters = true)
    @JoinColumn(name="customer_id",referencedColumnName = "Id")
    private Customer customerOrder;


    public Order(Integer orderId, String productName, String price, Customer customerOrder) {
        this.orderId = orderId;
        this.productName = productName;
        this.price = price;
        this.customerOrder = customerOrder;
    }

    public Order() {
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Customer getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(Customer customerOrder) {
        this.customerOrder = customerOrder;
    }
}
