package com.example.RelationshipsTest.Models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String customerName;

        @OneToMany(mappedBy = "customerOrder",cascade = CascadeType.ALL)
        private List<Order> orderList;

    public Customer(Integer id, String customerName, List<Order> orderList) {
        this.id = id;
        this.customerName = customerName;
        this.orderList = orderList;
    }

    public Customer() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }
}
