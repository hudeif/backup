package com.example.RelationshipsTest.Controllers;

import com.example.RelationshipsTest.Interfaces.ICustomer;
import com.example.RelationshipsTest.Interfaces.IOrder;
import com.example.RelationshipsTest.Models.Customer;
import com.example.RelationshipsTest.Models.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("orders")
public class OrderController {
    @Autowired
    IOrder iOrder;
    @Autowired
    ICustomer iCustomer;

    @GetMapping("/list")
    public List<Order> getAll(){
        return iOrder.findAll();
    }

    @GetMapping("/all")
    public List<Customer> get(){
        return iCustomer.findAll();
    }

}
