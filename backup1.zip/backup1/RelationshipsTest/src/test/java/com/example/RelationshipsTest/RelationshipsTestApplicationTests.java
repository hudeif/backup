package com.example.RelationshipsTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationshipsTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
