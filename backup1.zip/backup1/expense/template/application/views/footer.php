<script src="../../assets/js/vendor-all.min.js"></script>
<script src="../../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/pcoded.min.js"></script>
<script src="../js/sidebar.js"></script>
<!-- <script src="../../assets/js/table2excel.js"></script> -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
</body>
</html>