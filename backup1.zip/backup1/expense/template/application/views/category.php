<?php
session_start();
include 'header.php';
include 'sidebar.php';
?>

  <!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <!-- [ breadcrumb ] start -->

                <!-- [ breadcrumb ] end -->
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- [ Main Content ] start -->
                       <div class="row">
                            <div class="col-xl-12 main-datatable">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Categories</h5>
                                        <button id="addNew" class="btn btn-info float-right">Add new category</button>
                                        <div id="categoryModal" class="modal" tabindex="-1" role="dialog">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Expense</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form id="categoryForm">
                                                            <div class="alert alert-success d-none" role="alert">
                                                                This is a success alert—check it out!
                                                            </div>
                                                            <div class="alert alert-danger d-none" role="alert">
                                                                This is a danger alert—check it out!
                                                            </div>
                                                            <div class="form-group">
                                                                <input id="update_id" type="hidden" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">Name</label>
                                                                <input id="name" name="name" type="text" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">Icon</label>
                                                                <input id="icon" name="icon" type="text" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">Role</label>
                                                                <select name="role" id="role" class="form-control">
                                                                    <option value="subscriber">subscriber</option>
                                                                    <option value="superAdmin">superAdmin</option>
                                                                    <option value="dashbaord">Dashboard</option>
                                                                    <option value="test">Test</option>
                                                                    <option value="another">Another</option>
                                                                </select>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-primary">Save</button>
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <span class="d-block m-t-5">use class <code>table</code> inside table element</span> -->
                                    </div>
                                    <div class="card-block table-border-style">
                                        <div class="table-responsive">
                                            <table class="table cust-datatable dataTable no-footer" id="categoryTable">
                                                <thead>
                                                  
                                                </thead>
                                                <tbody>
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       </div>
                        <!-- [ Main Content ] end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- [ Main Content ] end -->
<?php

include 'footer.php';
?>

<script src="../js/category.js"></script>