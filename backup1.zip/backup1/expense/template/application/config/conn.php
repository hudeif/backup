<?php

$conn = new mysqli("localhost","root","","expense-gr");

if($conn->connect_error){
    echo $conn->error;
}