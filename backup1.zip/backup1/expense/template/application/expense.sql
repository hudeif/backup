-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2021 at 04:52 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expense`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `register_expense_sp`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `register_expense_sp` (IN `_id` INT, IN `_amount` FLOAT(11,2), IN `_type` VARCHAR(50) CHARSET utf8, IN `_desc` TEXT CHARSET utf8, IN `_userId` VARCHAR(50) CHARSET utf8)  BEGIN

if EXISTS (SELECT *FROM expense WHERE expense.id=_id) THEN

UPDATE expense SET expense.amount=_amount,expense.type=_type,expense.description=_desc WHERE expense.id=_id;

SELECT 'Updated' as Message;

ELSE

if(_type = 'Expense') THEN

if((SELECT get_user_balance_fn	(_userId) < _amount)) THEN

SELECT 'Deny' as Message;

ELSE

INSERT INTO expense (expense.amount,expense.type,expense.description,expense.user_id)
VALUES (_amount,_type,_desc,_userId);

SELECT 'Registered' as Message;

END if;

ELSE

INSERT INTO expense (expense.amount,expense.type,expense.description,expense.user_id)
VALUES (_amount,_type,_desc,_userId);

SELECT 'Registered' as Message;

END if;
END if;
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `get_user_balance_fn`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `get_user_balance_fn` (`_userId` VARCHAR(50)) RETURNS FLOAT(11,2) BEGIN

SET @balance = 0.00;

SET @income = ( SELECT SUM(expense.amount) FROM expense WHERE expense.type = 'Income' AND expense.user_id = _userId);

SET @expense = ( SELECT SUM(expense.amount) FROM expense WHERE expense.type = 'Expense' AND expense.user_id = _userId);

SET @balance = (ifnull(@income,0) - ifnull(@expense,0));
RETURN @balance;




END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `amount` float(11,2) NOT NULL,
  `type` varchar(15) NOT NULL,
  `description` text NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `amount`, `type`, `description`, `user_id`, `date`) VALUES
(29, 70.00, 'Income', 'from Bootstrap', 'USR001', '2021-08-05 11:47:32'),
(31, 3434.00, 'Income', 'mushaharaad', 'USR001', '2021-08-06 15:12:32'),
(34, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:18:06'),
(35, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:18:10'),
(39, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:23:01'),
(43, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:27:58'),
(44, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:28:43'),
(45, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:28:45'),
(47, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:28:47'),
(48, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:40:42'),
(49, 700.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:41:42'),
(50, 11950.00, 'Income', 'From Where', 'USR001', '2021-08-09 09:50:37'),
(51, 9.00, 'Expense', 'Prepaid', 'USR001', '2021-08-08 09:48:04'),
(52, 70.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:48:57'),
(54, 70.00, 'Income', 'From Where', 'USR001', '2021-08-08 09:49:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
