<?php

header("Content-type:application/json");

include '../config/conn.php';

function addCategory($conn){

    $data = array();

    extract($_POST);
    // prepare query
    $query = "INSERT INTO `category`(`name`, `icon`, `role`) VALUES('$name','$icon','$role')";

    $result = $conn->query($query);
    

    if($result){
        $data = array("status" => true,"data" => "Registered Successfully.");
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }

    echo json_encode($data);
}

function updateCategory($conn){

    $data = array();

    extract($_POST);
    // prepare query
    $query = "UPDATE category SET name = '$name',icon = '$icon', role = '$role' WHERE id = '$id'";

    $result = $conn->query($query);
    

    if($result){
        $data = array("status" => true,"data" => "Updated Succesfully.");
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }

    echo json_encode($data);
}

function categoryList($conn){
    $data = array();
    $array_data = array();

    $query = "SELECT * FROM category";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function getUserStatement($conn){
    extract($_POST);
    $data = array();
    $array_data = array();

    $query = "CALL get_user_statement_sp('USR001','$from','$to')";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function categoryInfo($conn){
    extract($_POST);

    $data = array();
    $array_data = array();

    $query = "SELECT * FROM category WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function deleteCategory($conn){
    extract($_POST);

    $data = array();

    $query = "DELETE FROM category WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $data = array("status" => true, "data" => "Deleted successfully.");
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status" => false,"data" => "Action Required."));
}