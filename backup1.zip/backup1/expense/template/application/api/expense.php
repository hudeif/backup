<?php
session_start();
header("Content-type:application/json");

include '../config/conn.php';

function register_expense($conn){

    $data = array();
    // $userId = $_SESSION['id'];
    extract($_POST);
    // prepare query
    $query = "CALL register_expense_sp('','$amount','$type','$description','USR001')";

    $result = $conn->query($query);
    

    if($result){
        $row = $result->fetch_assoc();
        if($row['Message'] == "Deny"){
            $data = array("status" => false,"data" => "Insuficiant Balance");
        }elseif ($row['Message'] == "Registered") {
            $data = array("status" => true,"data" => "Registered.");
        }
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }

    echo json_encode($data);
}

function updateTrans($conn){

    $data = array();
    $userId = $_SESSION['id'];
    extract($_POST);
    // prepare query
    $query = "CALL update_expense_sp('$id', $amount, '$type', '$description', '$userId');";

    $result = $conn->query($query);

    if($result){
        $row = $result->fetch_assoc();
        if($row['Message'] == 'Deny'){
            $data = array("status" => false,"data" => "Insuficiant Balance.");
        }elseif ($row['Message'] == 'Updated') {
            $data = array("status" => true,"data" => "Updated Succesfully.");
        }
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }
    
    

    echo json_encode($data);
}

function allTransactions($conn){
    $data = array();
    $array_data = array();

    $query = "SELECT id,amount,type,description,`user_id` FROM expense";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function getUserStatement($conn){
    extract($_POST);
    $data = array();
    $array_data = array();

    $query = "CALL get_user_statement_sp('USR001','$from','$to')";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function transInfo($conn){
    extract($_POST);

    $data = array();
    $array_data = array();

    $query = "SELECT * FROM expense WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function deleteTrans($conn){
    extract($_POST);
    $data = array();

    $query = "DELETE FROM expense WHERE id = '$id'";
    
    $result = $conn->query($query);
    if($result){
        $data = array("status" => true, "data" => "Deleted successfully.");
        
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }
    
   

    

    echo json_encode($data);
}


if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status" => false,"data" => "Action Required."));
}