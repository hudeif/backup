<?php

header("Content-type:application/json");

include '../config/conn.php';

function readSystemLinks(){
    $data = array();
    $data_array = array();

    $search_result = glob('../views/*.php');

    foreach($search_result as $sr){
        $pure_link = explode('/',$sr);
        $data_array [] = $pure_link[2];
    }

    if(count($search_result) > 0){
        $data = array("satus" => true, "data" => $data_array);
    }else{
        $data = array("satus" => false, "data" => 'No files found');
    }

    echo json_encode($data);
}

function addLink($conn){

    $data = array();

    extract($_POST);
    // prepare query
    $query = "INSERT INTO `system_links`(`name`, `link`, `category_id`) VALUES('$name','$link','$category')";

    $result = $conn->query($query);
    

    if($result){
        $data = array("status" => true,"data" => "Registered Successfully.");
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }

    echo json_encode($data);
}

function updateLink($conn){

    $data = array();

    extract($_POST);
    // prepare query
    $query = "UPDATE system_links SET name = '$name',link = '$link', 
    category_id = '$category' WHERE id = '$id'";

    $result = $conn->query($query);
    

    if($result){
        $data = array("status" => true,"data" => "Updated Succesfully.");
    }else{
        $data = array("status" => false,"data" => $conn->error);
    }

    echo json_encode($data);
}

function dbLinkList($conn){
    $data = array();
    $array_data = array();

    $query = "SELECT * FROM system_links";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }
        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


function linkInformation($conn){
    extract($_POST);

    $data = array();
    $array_data = array();

    $query = "SELECT * FROM system_links WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function deleteLink($conn){
    extract($_POST);

    $data = array();

    $query = "DELETE FROM system_links WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $data = array("status" => true, "data" => "Deleted successfully.");
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status" => false,"data" => "Action Required."));
}