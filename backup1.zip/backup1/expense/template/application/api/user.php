<?php

header("Content-type:application/json");

include '../config/conn.php';

function addUser($conn){

    $data = array();
    $error_Array = array();

    $new_id = generateId($conn);
    extract($_POST);

    $file_name = $_FILES['image']['name'];
    $file_type = $_FILES['image']['type'];
    $file_size = $_FILES['image']['size'];

    $save_name = $new_id.'.png';

    $allowedImages = ["image/jpg","image/jpeg","image/png"];
    $max_size = 5 * 1024 * 1024;

    if(in_array($file_type,$allowedImages)){
        if($file_size > $max_size){
            $error_Array [] = 'The file must be less than '.$max_size;
        }
    }else{
        $error_Array [] = "This file is not allowed.".$file_type;
    }

    if(count($error_Array) <= 0){
        // prepare query
        $query = "INSERT INTO `users`(`id`, `username`, `password`,`image`) 
        VALUES ('$new_id','$username',MD5('$password'),'$save_name')";
    
        $result = $conn->query($query);
        
    
        if($result){
            move_uploaded_file($_FILES['image']['tmp_name'],"../uploads/".$save_name);
            $data = array("status" => true,"data" => "Registered succeessFully.");
        }else{
            $data = array("status" => false,"data" => $conn->error);
        }
    }else{
        $data = array("status" => false,"data" => $error_Array);
    }

    echo json_encode($data);
}


function updateUser($conn){
    extract($_POST);

    $data = array();


    if(!empty($_FILES['image']['tmp_name'])){
        $error_Array = array();

        $file_name = $_FILES['image']['name'];
        $file_type = $_FILES['image']['type'];
        $file_size = $_FILES['image']['size'];

        $save_name = $update_id.'.png';

        $allowedImages = ["image/jpg","image/jpeg","image/png"];
        $max_size = 5 * 1024 * 1024;

        if(in_array($file_type,$allowedImages)){
            if($file_size > $max_size){
                $error_Array [] = 'The file must be less than '.$max_size;
            }
        }else{
            $error_Array [] = "This file is not allowed.".$file_type;
        }

        if(count($error_Array) <= 0){
            // prepare query
            $query = "UPDATE users set username = '$username', password = MD5('$password')
             WHERE users.id = '$update_id'";
        
            $result = $conn->query($query);
            
        
            if($result){
                move_uploaded_file($_FILES['image']['tmp_name'],"../uploads/".$save_name);
                $data = array("status" => true,"data" => "Updated succeessFully.");
            }else{
                $data = array("status" => false,"data" => $conn->error);
            }
        }else{
            $data = array("status" => false,"data" => $error_Array);
        }

    }else{
        $query = "UPDATE users set username = '$username', password = MD5('$password')
        WHERE users.id = '$update_id'";
   
       $result = $conn->query($query);
       
   
       if($result){
           $data = array("status" => true,"data" => "Updated succeessFully.");
       }else{
           $data = array("status" => false,"data" => $conn->error);
       }
    }
    
    echo json_encode($data);
}



function allUsers($conn){
    $data = array();
    $array_data = array();

    $query = "SELECT * FROM users";
    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }

        $data = array("status" => true, "data" => $array_data);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function generateId($conn){
    $new_id = '';
    $data = array();

    $query = "SELECT id FROM users order by users.id desc limit 1";
    $result = $conn->query($query);

    if($result){
        $num_rows = $result->num_rows;

        if($num_rows > 0){
            $row = $result->fetch_assoc();
            $new_id = ++$row['id'];
        }else{
            $new_id = 'USR001';
        }
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo $new_id;
}

function userInfo($conn){
    extract($_POST);

    $data = array();
    $array_data = array();

    $query = "SELECT * FROM users WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        $row = $result->fetch_assoc();

        $data = array("status" => true, "data" => $row);
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}

function deleteUser($conn){
    extract($_POST);

    $data = array();

    $query = "DELETE FROM users WHERE id = '$id'";
    $result = $conn->query($query);

    if($result){
        unlink('../uploads/'.$id.'.png');
        $data = array("status" => true, "data" => "Deleted successfully.");
    }else{
        $data = array("status" => false, "data" => $conn->error);
    }

    echo json_encode($data);
}


if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status" => false,"data" => "Action Required."));
}