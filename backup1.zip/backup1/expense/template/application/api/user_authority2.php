<?php

header("content-type: application/json");
include '../config/conn.php';

function readSystemAuthorities($conn){
   
    $data = array();
    $array_data = array();

    $query = "SELECT * FROM `system_authorities_vw`";


    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }

        $data = array("status" => true, "data" =>$array_data);

    }else{
        $data = array("status" => false, "data" =>$conn->error);
    }
    echo json_encode($data);
}
function getUserAuthorities($conn){
    extract($_POST);
    $data = array();
    $array_data = array();

    $query = "CALL get_user_authorities_sp('$user_id')";


    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }

        $data = array("status" => true, "data" =>$array_data);

    }else{
        $data = array("status" => false, "data" =>$conn->error);
    }
    echo json_encode($data);
}

function getUserMenus($conn){
    extract($_POST);
    $data = array();
    $array_data = array();

    $query = "CALL get_user_menu_sp('USR001')";


    $result = $conn->query($query);

    if($result){
        while($row = $result->fetch_assoc()){
            $array_data [] = $row;
        }

        $data = array("status" => true, "data" =>$array_data);

    }else{
        $data = array("status" => false, "data" =>$conn->error);
    }
    echo json_encode($data);
}



function user_authorized($conn){
    extract($_POST);
    $data = array();
    $success_array = array();
    $error_array = array();

    $del = "DELETE FROM  user_authority where user_id = '$user_id'";
    $conn = new mysqli("localhost","root", "","expense-gr");
    $res = $conn->query($del);
    if($res){
        for($i =0; $i < count($action_id); $i++ ){
          $query = "INSERT INTO `user_authority`(`user_id`, `action_id`) VALUES ('$user_id', '$action_id[$i]')";
          
          $result = $conn->query($query);
        if($result){

            $success_array [] = array("status" => true, "data" => "Registered");
        }else{
            $error_array [] = array("status" => false, "data" => $conn->error);
        }
    }
        
    }else{
        $error_array [] = array("status" => false, "data" => $conn->error);
    }

    if(count($success_array) > 0 && count($error_array) == 0){
        $data = array("status" => true, "data" => $success_array);

    }elseif(count($success_array) >0){
        $data = array("status" => false, "data" => $error_array);
    }

    if(count($error_array) > 0 && count($success_array) == 0){
        $data = array("status" => false, "data" => $error_array);
    }
    echo json_encode($data);
}


if(isset($_POST['action'])){
    $action = $_POST['action'];
    $action($conn);
    
}else{
    echo json_encode(array("status" => false, "data" => "Action Required..."));
}

?>

