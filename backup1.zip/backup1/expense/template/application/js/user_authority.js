authorityList();
fillUsers();

$("#all_authority").on("change", function () {
  if ($(this).is(":checked")) {
    $("input[type='checkbox']").prop("checked", true);
  } else {
    $("input[type='checkbox']").prop("checked", false);
  }
});

$("#authorityArea").on("change", 'input[name="role_authority[]"]', function () {
  let value = $(this).val();
  if ($(this).is(":checked")) {
    $(`input[type='checkbox'][role="${value}"]`).prop("checked", true);
  } else {
    $(`input[type='checkbox'][role="${value}"]`).prop("checked", false);
  }
});

$("#authorityArea").on("change", 'input[name="system_link[]"]', function () {
  let link = $(this).attr("link_id");
  //   let value = $(this).val(); you also can use this
  if ($(this).is(":checked")) {
    $(`input[type='checkbox'][link_id="${link}"]`).prop("checked", true);
  } else {
    $(`input[type='checkbox'][link_id="${link}"]`).prop("checked", false);
  }
});

$("#authorityForm").submit(function (event) {
  event.preventDefault();

  let actions = [];
  let user_id = $("#user_id").val();

  if (user_id == "") {
    alert("please select User.");
    return;
  }

  $("input[name='system_action[]']").each(function () {
    if ($(this).is(":checked")) {
      actions.push($(this).val());
    }
  });

  let sendingData = {
    user_id,
    action_id: actions,
    action: "authorizeUser",
  };

  console.log(sendingData);
  $.ajax({
    method: "POST",
    url: "../api/user_authority.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        response.forEach((res) => {
          $(".alert-success").removeClass("d-none");
          $(".alert-danger").addClass("d-none");
          $(".alert-success").html(`<p>${res["data"]}</p>`);
        });
      } else {
        response.forEach((res) => {
          $(".alert-danger").removeClass("d-none");
          $(".alert-success").addClass("d-none");
          $(".alert-danger").html(`<p class="mb-0">${res["data"]}</p>`);
        });
      }
    },
    error: function (data) {
      console.log(response);
    },
  });
});

$("#user_id").on("change", function () {
  let value = $(this).val();
  loadUserPermission(value);
});
function fillUsers() {
  let sendingData = {
    action: "allUsers",
  };

  $.ajax({
    method: "POST",
    url: "../api/user.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";

      response.forEach((item) => {
        html += `<option value="${item["id"]}">${item["username"]}</option>`;
      });

      $("#user_id").append(html);
      $("#linkTable").DataTable();
    },
    error: function (data) {},
  });
}

function loadUserPermission(id) {
  $("input[type='checkbox']").prop("checked", false);
  let sendingData = {
    action: "getUserAuthorities",
    user_id: id,
  };

  $.ajax({
    method: "POST",
    url: "../api/user_authority.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        if (response.length >= 1) {
          response.forEach((user) => {
            $(
              `input[type="checkbox"][name="role_authority[]"][value="${user["role"]}"]`
            ).prop("checked", true);

            $(
              `input[type="checkbox"][name="system_link[]"][value="${user["link_id"]}"]`
            ).prop("checked", true);

            $(
              `input[type="checkbox"][name="system_action[]"][value="${user["action_id"]}"]`
            ).prop("checked", true);
          });
        } else {
          $("input[type='checkbox']").prop("checked", false);
        }
      }
    },
    error: function (data) {},
  });
}

function authorityList() {
  let sendingData = {
    action: "readSystemAuthorities",
  };

  $.ajax({
    method: "POST",
    url: "../api/user_authority.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let role = "";
      let system_links = "";
      let system_actions = "";
      if (status) {
        response.forEach((item) => {
          for (let i in item) {
            if (item["role"] !== role) {
              html += `
                    </fieldset>
                    </div></div>
    
                    <div class="item" style="margin:10px">
                        <fieldset class="authority-border">
                            <legend class="authority-border">
                                <input type="checkbox"id name="role_authority[]"
                                 value="${item["role"]}">
                               ${item["role"]}
                            </legend>
                    `;
              role = item["role"];
            }

            if (item["name"] !== system_links) {
              html += `
                <div class="control-group">
                <label class="control-label ml-4">
                    <input type="checkbox" class="mr-2" name="system_link[]" role="${item["role"]}"
                    id="" link_id="${item["link_id"]}" category_id="${item["id"]}" 
                    value="${item["link_id"]}">
                    ${item["name"]}
                </label>
                `;

              system_links = item["name"];
            }

            if (item["action_name"] !== system_actions) {
              html += `
                    <div class="system_action">
                    <label class="control-label ml-5">
                        <input type="checkbox" class="mr-2" name="system_action[]" role="${item["role"]}"
                        id="" link_id="${item["link_id"]}" category_id="${item["id"]}" 
                        value="${item["action_id"]}" action_id="${item["action_id"]}">
                        ${item["action_name"]}
                    </label>
                    </div>
                `;
              system_actions = item["action_name"];
            }
          }
        });
        $("#authorityArea").append(html);
      } else {
      }
    },
    error: function (data) {},
  });
}
