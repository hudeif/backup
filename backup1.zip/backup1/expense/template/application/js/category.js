categoryList();
btnAction = "Insert";

$("#addNew").click(function () {
  $("#categoryModal").modal("show");
});

// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      $("#categoryModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#categoryForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#categoryForm").submit(function (event) {
  event.preventDefault();

  let name = $("#name").val();
  let icon = $("#icon").val();
  let role = $("#role").val();
  let id = $("#update_id").val();

  let sendingData = {};

  if (btnAction == "Insert") {
    sendingData = {
      name,
      icon,
      role,
      action: "addCategory",
    };
  } else {
    sendingData = {
      id,
      name,
      icon,
      role,
      action: "updateCategory",
    };
  }

  $.ajax({
    method: "POST",
    url: "../api/category.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        displayMessage("success", response);
        btnAction = "Insert";
        categoryList();
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {
      displayMessage("error", data.responseText);
    },
  });
});

function categoryList() {
  $("#categoryTable tr").html("");

  let sendingData = {
    action: "categoryList",
  };

  $.ajax({
    method: "POST",
    url: "../api/category.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";
      let th = "";

      response.forEach((item) => {
        th = "<tr>";
        for (let i in item) {
          th += `<th>${i}</th>`;
        }
        th += "<th>Action</th></tr>";
        tr += "<tr>";
        for (let i in item) {
          tr += `<td>${item[i]}</td>`;
        }

        tr += `<td>
            <a class="update_category" update_category="${item["id"]}"><i class="fas fa-edit text-primary"></i></a>
            &nbsp;&nbsp;<a class="delete_category" delete_category="${item["id"]}"><i class="fas fa-trash text-danger"></i></a>
          </td>`;
        tr += "</tr>";
      });
      $("#categoryTable thead").append(th);
      $("#categoryTable tbody").append(tr);
      $("#categoryTable").DataTable();
    },
    error: function (data) {},
  });
}

function getCategoryInfo(id) {
  let sendingData = {
    id: id,
    action: "categoryInfo",
  };

  $.ajax({
    method: "POST",
    url: "../api/category.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        $("#update_id").val(response.id);
        $("#name").val(response.name);
        $("#icon").val(response.icon);
        $("#role").val(response.role);
        $("#categoryModal").modal("show");
        btnAction = "Update";
      } else {
      }
    },
    error: function (data) {},
  });
}

function deleteCategory(id) {
  let sendingData = {
    id: id,
    action: "deleteCategory",
  };

  $.ajax({
    method: "POST",
    url: "../api/category.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        categoryList();
      } else {
        swal("Sorry!", response, "error");
      }
    },
    error: function (data) {
      swal("", data.responseText, "error");
    },
  });
}

$("#categoryTable").on("click", "a.update_category", function () {
  let id = $(this).attr("update_category");
  console.log(id);
  getCategoryInfo(id);
});

$("#categoryTable").on("click", "a.delete_category", function () {
  let id = $(this).attr("delete_category");
  console.log(id);
  if (confirm("Are you sure to delete?")) {
    deleteCategory(id);
  }
});
