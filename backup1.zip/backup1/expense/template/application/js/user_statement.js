$("#from").attr("disabled", true);
$("#to").attr("disabled", true);

$("#type").on("change", function () {
  if ($(this).val() == 0) {
    $("#from").attr("disabled", true);
    $("#to").attr("disabled", true);
    $("#from").val("");
    $("#to").val("");
  } else {
    $("#from").attr("disabled", false);
    $("#to").attr("disabled", false);
  }
});
// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      $("#expenseModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#expenseForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#statementForm").submit(function (event) {
  event.preventDefault();
  $("#statementTable tr").html("");
  let from = $("#from").val();
  let to = $("#to").val();

  let sendingData = {
    from,
    to,
    action: "getUserStatement",
  };

  $.ajax({
    method: "POST",
    url: "../api/expense.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";
      let th = "";

      response.forEach((item) => {
        //    console.log(item);
        th = "<tr>";

        for (let i in item) {
          th += `<th>${i}</th>`;
        }

        th += "</tr>";

        tr += "<tr>";
        for (let i in item) {
          if (i == "Income") {
            if (item[i] == null) {
              tr += `<td>$0.00</td>`;
            } else if (item[i] == "0.00") {
              tr += `<td></td>`;
            } else {
              tr += `<td>${item[i]}</td>`;
            }
          } else if (i == "Expense") {
            if (item[i] == null) {
              tr += `<td>$0.00</td>`;
            } else if (item[i] == "0.00") {
              tr += `<td></td>`;
            } else {
              tr += `<td>${item[i]}</td>`;
            }
          } else {
            tr += `<td>${item[i]}</td>`;
          }
        }
        tr += "</tr>";
      });
      $("#statementTable thead").append(th);
      $("#statementTable tbody").append(tr);
    },
    error: function (data) {},
  });
});

$("#print_statement").click(function () {
  printStatement();
});

function printStatement() {
  let content = document.querySelector("#print_area");

  let newWindow = window.open("");

  newWindow.document.write(`<html><head><title></title>`);

  newWindow.document.write(`<style media="print">
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

    body{
        font-family: 'Poppins', sans-serif;
        font-size:0.9rem;
    }

    table{
        width:100%;
        border-collapse:collapse;
        text-align:left;
    }
    td{
        padding:0.5rem 2rem !important;
    }
    th{
        background:#5d9bff !important;
        padding:0.8rem 2rem;
        color:white !important;
        text-transform:upprcase;
        font-weight:600;
    }
    td{
        border-bottom:1px solid #ddd !important;
    }

    tr:nth-child(even) {
        background: #f4f6fb;
    }

    tr:last-child td{
        font-weight:500 !important;
    }
   
 
    tr th:nth-child(2){
       display:none;
    }
    tr td:nth-child(2){
       display:none;
    }

    img {
        opacity: 0.3 !important;
        position: absolute !important;
        left: 2% !important;
        top: 100px !important;
    }

    .title{
        text-align:center;
    }

    </style>`);
  newWindow.document.write(`</head><body>`);
  // newWindow.document.write(`<img class="logo-print" src="../views/money.png">`) =>some problem;
  newWindow.document.write(`<h1 class="title">STATEMENT</h1>`);
  newWindow.document.write(`<h3 class="title">USR001</h3>`);
  newWindow.document.write(content.innerHTML);
  newWindow.document.write(`</body></html`);
  newWindow.print();
  newWindow.close();
}
