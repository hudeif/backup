loadUsers();
btnAction = "Insert";

$(".modal").on("hidden.bs.modal", function () {
  $("#userForm")[0].reset();
});

let imageFile = document.querySelector("#image");
let showImage = document.querySelector("#show");

const reader = new FileReader();

imageFile.addEventListener("change", (e) => {
  const selectedFile = e.target.files[0];
  reader.readAsDataURL(selectedFile);
});

reader.onload = (e) => {
  showImage.src = e.target.result;
};

$("#addNew").click(function () {
  $("#userModal").modal("show");
});

// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      $("#userModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#userForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#userForm").submit(function (event) {
  event.preventDefault();

  let formData = new FormData($("#userForm")[0]);
  formData.append("image", $("input[type=file]")[0].files[0]);

  if (btnAction == "Insert") {
    formData.append("action", "addUser");
  } else {
    formData.append("action", "updateUser");
  }

  $.ajax({
    method: "POST",
    url: "../api/user.php",
    dataType: "JSON",
    data: formData,
    processData: false,
    contentType: false,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        displayMessage("success", response);
        btnAction = "Insert";
        $("#userForm")[0].reset();
        loadUsers();
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {},
  });
});

function loadUsers() {
  $("#userTable tbody").html("");

  let sendingData = {
    action: "allUsers",
  };

  $.ajax({
    method: "POST",
    url: "../api/user.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";

      response.forEach((item) => {
        tr += "<tr>";
        for (let i in item) {
          if (i == "image") {
            tr += `<td><img src="../uploads/${item[i]}" style="width:50px;height:50px;border-radius:50%; object-fit:cover;"></td>`;
          } else {
            tr += `<td>${item[i]}</td>`;
          }
        }
        tr += `<td>
            <a class="update_user" update_user="${item["id"]}"><i class="fas fa-edit text-primary"></i></a>
            &nbsp;&nbsp;<a class="delete_user" delete_user="${item["id"]}"><i class="fas fa-trash text-danger"></i></a>
          </td>`;
        tr += "</tr>";
      });
      $("#userTable tbody").append(tr);
      $("#userTable").DataTable();
    },
    error: function (data) {},
  });
}

function getUserInfo(id) {
  let sendingData = {
    id: id,
    action: "userInfo",
  };

  $.ajax({
    method: "POST",
    url: "../api/user.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        $("#update_id").val(response.id);
        $("#username").val(response.username);
        $("#show").attr("src", `../uploads/${response.image}`);
        $("#userModal").modal("show");
        btnAction = "Update";
      } else {
      }
    },
    error: function (data) {},
  });
}

function deleteUser(id) {
  let sendingData = {
    id: id,
    action: "deleteUser",
  };

  $.ajax({
    method: "POST",
    url: "../api/user.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        loadUsers();
      } else {
        swal("Sorry!", response, "error");
      }
    },
    error: function (data) {},
  });
}

$("#userTable").on("click", "a.update_user", function () {
  let id = $(this).attr("update_user");
  getUserInfo(id);
});

$("#userTable").on("click", "a.delete_user", function () {
  let id = $(this).attr("delete_user");
  console.log(id);
  if (confirm("Are you sure to delete?")) {
    deleteUser(id);
  }
});
