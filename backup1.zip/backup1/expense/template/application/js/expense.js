loadTransactions();
btnAction = "Insert";

$("#addNew").click(function () {
  $("#expenseModal").modal("show");
});

// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      $("#expenseModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#expenseForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#expenseForm").submit(function (event) {
  event.preventDefault();

  let amount = $("#amount").val();
  let type = $("#type").val();
  let description = $("#description").val();
  let id = $("#update_id").val();

  let sendingData = {};

  if (btnAction == "Insert") {
    sendingData = {
      amount,
      type,
      description,
      action: "register_expense",
    };
  } else {
    sendingData = {
      id,
      amount,
      type,
      description,
      action: "updateTrans",
    };
  }

  $.ajax({
    method: "POST",
    url: "../api/expense.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        displayMessage("success", response);
        btnAction = "Insert";
        loadTransactions();
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {},
  });
});

function loadTransactions() {
  $("#expenseTable tbody").html("");

  let sendingData = {
    action: "allTransactions",
  };

  $.ajax({
    method: "POST",
    url: "../api/expense.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";

      response.forEach((item) => {
        tr += "<tr>";
        for (let i in item) {
          if (i == "type") {
            if (item[i] == "Income") {
              tr += `<td><p class="badge badge-success type py-1 px-2 mb-0">${item[i]}</p></td>`;
            } else {
              tr += `<td><p class="badge badge-danger type py-1 px-2 mb-0">${item[i]}</p></td>`;
            }
          } else {
            tr += `<td>${item[i]}</td>`;
          }
        }
        tr += `<td>
            <a class="update_trans" update_trans="${item["id"]}"><i class="fas fa-edit text-primary"></i></a>
            &nbsp;&nbsp;<a class="delete_trans" delete_trans="${item["id"]}"><i class="fas fa-trash text-danger"></i></a>
          </td>`;
        tr += "</tr>";
      });
      $("#expenseTable tbody").append(tr);
      $("#expenseTable").DataTable();
    },
    error: function (data) {},
  });
}

function getTransInfo(id) {
  let sendingData = {
    id: id,
    action: "transInfo",
  };

  $.ajax({
    method: "POST",
    url: "../api/expense.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        $("#update_id").val(response.id);
        $("#amount").val(response.amount);
        $("#type").val(response.type);
        $("#description").val(response.description);
        $("#expenseModal").modal("show");
        btnAction = "Update";
      } else {
      }
    },
    error: function (data) {},
  });
}

function deleteTrans(id) {
  let sendingData = {
    id: id,
    action: "deleteTrans",
  };

  $.ajax({
    method: "POST",
    url: "../api/expense.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        loadTransactions();
      } else {
        swal("Sorry!", response, "error");
      }
    },
    error: function (data) {
      console.log(data);
    },
  });
}

$("#expenseTable").on("click", "a.update_trans", function () {
  let id = $(this).attr("update_trans");
  console.log(id);
  getTransInfo(id);
});

$("#expenseTable").on("click", "a.delete_trans", function () {
  let id = $(this).attr("delete_trans");
  if (confirm("Are you sure to delete?")) {
    deleteTrans(id);
  }
});
