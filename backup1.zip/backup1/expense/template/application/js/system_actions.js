systemActionList();
fillLinks();
btnAction = "Insert";

$("#addNew").click(function () {
  $("#actionModal").modal("show");
});

// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      // $("#actionModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#actionForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#actionForm").submit(function (event) {
  event.preventDefault();

  let name = $("#name").val();
  let system_action = $("#system_action").val();
  let link_id = $("#link_id").val();
  let id = $("#update_id").val();

  let sendingData = {};

  if (btnAction == "Insert") {
    sendingData = {
      name: name,
      link_id: link_id,
      system_action: system_action,
      action: "addSystemAction",
    };
  } else {
    sendingData = {
      id,
      name: name,
      link_id: link_id,
      system_action: system_action,
      action: "updateSystemAction",
    };
  }

  $.ajax({
    method: "POST",
    url: "../api/system_actions.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        displayMessage("success", response);
        btnAction = "Insert";
        $("#actionForm")[0].reset();
        systemActionList();
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {
      displayMessage("error", data.responseText);
    },
  });
});

function systemActionList() {
  $("#actionTable tr").html("");

  let sendingData = {
    action: "systemActions",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_actions.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";
      let th = "";

      response.forEach((item) => {
        th = "<tr>";
        for (let i in item) {
          th += `<th>${i}</th>`;
        }
        th += "<th>Action</th></tr>";
        tr += "<tr>";
        for (let i in item) {
          tr += `<td>${item[i]}</td>`;
        }

        tr += `<td>
            <a class="update_action" update_action="${item["id"]}"><i class="fas fa-edit text-primary"></i></a>
            &nbsp;&nbsp;<a class="delete_action" delete_action="${item["id"]}"><i class="fas fa-trash text-danger"></i></a>
          </td>`;
        tr += "</tr>";
      });
      $("#actionTable thead").append(th);
      $("#actionTable tbody").append(tr);
      $("#actionTable").DataTable();
    },
    error: function (data) {},
  });
}

function fillLinks() {
  let sendingData = {
    action: "dbLinkList",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";

      response.forEach((item) => {
        html += `<option value="${item["id"]}">${item["name"]}</option>`;
      });

      $("#link_id").append(html);
      $("#actionTable").DataTable();
    },
    error: function (data) {},
  });
}

function getActionInfo(id) {
  let sendingData = {
    id: id,
    action: "actionInfo",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_actions.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        console.log(response);
        $("#update_id").val(response.id);
        $("#name").val(response.name);
        $("#system_action").val(response.action);
        $("#link_id").val(response.link_id);
        $("#actionModal").modal("show");
        btnAction = "Update";
      } else {
      }
    },
    error: function (data) {},
  });
}

function deleteAction(id) {
  let sendingData = {
    id: id,
    action: "deleteSystemAction",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_actions.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        systemActionList();
      } else {
        swal("Sorry!", response, "error");
      }
    },
    error: function (data) {
      swal("", data.responseText, "error");
    },
  });
}

$("#actionTable").on("click", "a.update_action", function () {
  let id = $(this).attr("update_action");
  console.log(id);
  getActionInfo(id);
});

$("#actionTable").on("click", "a.delete_action", function () {
  let id = $(this).attr("delete_action");
  console.log(id);
  if (confirm("Are you sure to delete?")) {
    deleteAction(id);
  }
});
