linkList();
fillLinks();
fillCategory();
btnAction = "Insert";

$("#addNew").click(function () {
  $("#linkModal").modal("show");
});

// alerts function

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      $("#linkModal").modal("hide");
      success.classList = "alert alert-success d-none";
      $("#linkForm")[0].reset();
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // some problem to ask the teacher => how to reset form if is error
  }
}

$("#linkForm").submit(function (event) {
  event.preventDefault();

  let name = $("#name").val();
  let link_id = $("#link_id").val();
  let category_id = $("#category_id").val();
  let id = $("#update_id").val();

  let sendingData = {};

  if (btnAction == "Insert") {
    sendingData = {
      name: name,
      link: link_id,
      category: category_id,
      action: "addLink",
    };
  } else {
    sendingData = {
      id,
      name,
      link: link_id,
      category: category_id,
      action: "updateLink",
    };
  }

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        displayMessage("success", response);
        btnAction = "Insert";
        linkList();
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {
      displayMessage("error", data.responseText);
    },
  });
});

function linkList() {
  $("#linkTable tr").html("");

  let sendingData = {
    action: "dbLinkList",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let tr = "";
      let th = "";

      response.forEach((item) => {
        th = "<tr>";
        for (let i in item) {
          th += `<th>${i}</th>`;
        }
        th += "<th>Action</th></tr>";
        tr += "<tr>";
        for (let i in item) {
          tr += `<td>${item[i]}</td>`;
        }

        tr += `<td>
            <a class="update_link" update_link="${item["id"]}"><i class="fas fa-edit text-primary"></i></a>
            &nbsp;&nbsp;<a class="delete_link" delete_link="${item["id"]}"><i class="fas fa-trash text-danger"></i></a>
          </td>`;
        tr += "</tr>";
      });
      $("#linkTable thead").append(th);
      $("#linkTable tbody").append(tr);
      $("#linkTable").DataTable();
    },
    error: function (data) {},
  });
}

function fillLinks() {
  let sendingData = {
    action: "readSystemLinks",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";

      response.forEach((item) => {
        html += `<option value="${item}">${item}</option>`;
      });

      $("#link_id").append(html);
      $("#linkTable").DataTable();
    },
    error: function (data) {},
  });
}

function fillCategory() {
  let sendingData = {
    action: "categoryList",
  };

  $.ajax({
    method: "POST",
    url: "../api/category.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";

      response.forEach((item) => {
        html += `<option value="${item["id"]}">${item["name"]}</option>`;
      });

      $("#category_id").append(html);
      $("#linkTable").DataTable();
    },
    error: function (data) {},
  });
}

function getlinkInfo(id) {
  let sendingData = {
    id: id,
    action: "linkInformation",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        $("#update_id").val(response.id);
        $("#name").val(response.name);
        $("#link_id").val(response.link);
        $("#category_id").val(response.category_id);
        $("#linkModal").modal("show");
        btnAction = "Update";
      } else {
      }
    },
    error: function (data) {},
  });
}

function deletelink(id) {
  let sendingData = {
    id: id,
    action: "deletelink",
  };

  $.ajax({
    method: "POST",
    url: "../api/system_links.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        swal("Good job!", response, "success");
        linkList();
      } else {
        swal("Sorry!", response, "error");
      }
    },
    error: function (data) {
      swal("", data.responseText, "error");
    },
  });
}

$("#linkTable").on("click", "a.update_link", function () {
  let id = $(this).attr("update_link");
  console.log(id);
  getlinkInfo(id);
});

$("#linkTable").on("click", "a.delete_link", function () {
  let id = $(this).attr("delete_link");
  console.log(id);
  if (confirm("Are you sure to delete?")) {
    deletelink(id);
  }
});
