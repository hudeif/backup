loadMenu();

setTimeout(() => {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => {
      item.classList.toggle("pcoded-trigger");

      //   item.querySelector(".pcoded-hasmenu").classList.toggle("show-menu-now");
      let sumbenu = item.querySelector(".pcoded-submenu");
      sumbenu.style.transition = "3s";

      if (!sumbenu.style.display) {
        sumbenu.style.display = "block";
      } else if (sumbenu.style.display == "none") {
        sumbenu.style.display = "block";
      } else {
        sumbenu.style.display = "none";
      }
      console.log(sumbenu);
    });
  });
}, 1000);
function loadMenu() {
  let sendingData = {
    action: "getUserMenu",
  };

  $.ajax({
    method: "POST",
    url: "../api/user_authority.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      let html = "";
      let menuElement = "";
      let category = "";

      if (status) {
        response.forEach((menu) => {
          if (menu["category_name"] != category) {
            if (category !== "") {
              menuElement += `</ul></li>`;
            }
            menuElement += `
                <li data-username="basic components Button Alert Badges breadcrumb Paggination progress Tooltip popovers Carousel Cards Collapse Tabs pills Modal Grid System Typography Extra Shadows Embeds" class="nav-item pcoded-hasmenu">
                <a href="javascript:" class="nav-link "><span class="pcoded-micon"><i class="feather icon-box"></i></span><span class="pcoded-mtext">${menu["category_name"]}</span></a>
                <ul class="pcoded-submenu">
                `;
            category = menu["category_name"];
          }

          menuElement += `
          <li class=""><a href="${menu["link"]}" class="">${menu["link_name"]}</a></li>
          `;
        });

        $("#user_menu").append(menuElement);
      }
    },
    error: function (data) {},
  });
}
