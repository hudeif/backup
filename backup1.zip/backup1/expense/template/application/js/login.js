$("#loginForm").submit((event) => {
  event.preventDefault();
  login();
});

function login() {
  let username = $("#username").val();
  let password = $("#password").val();

  let sendingData = {
    username,
    password,
    action: "login",
  };

  $.ajax({
    method: "POST",
    url: "../api/login.php",
    dataType: "JSON",
    data: sendingData,
    success: function (data) {
      let status = data.status;
      let response = data.data;

      if (status) {
        window.location.href = "../views/dashboard.php";
      } else {
        displayMessage("error", response);
      }
    },
    error: function (data) {},
  });
}

function displayMessage(type, message) {
  let success = document.querySelector(".alert-success");
  let error = document.querySelector(".alert-danger");

  if (type == "success") {
    error.classList = "alert alert-danger d-none";
    success.classList = "alert alert-success";
    success.innerHTML = message;

    setTimeout(function () {
      success.classList = "alert alert-success d-none";
    }, 3000);
  } else {
    error.classList = "alert alert-danger";
    error.innerHTML = message;
    // setTimeout(function () {
    //   error.classList = "alert alert-danger d-none";
    // }, 3000);
    // $("#username").val("");
    $("#password").val("");
    // some problem to ask the teacher => how to reset form if is error
  }
}
